// Default seed data (completely empty)
const initialRequests = [];

// APU Campus Coordinates & 10-Mile Radius Limit (10 miles ≈ 16,093 meters)
const APU_COORDS = [3.0480, 101.6918];
const MAX_RADIUS_METERS = 16093; 

const STORAGE_KEY = 'apu_food_requests_v3';

// Escape user-entered text before putting it into innerHTML (prevents script injection)
function esc(v) {
    return String(v ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}

function loadRequests() {
    try {
        const data = JSON.parse(localStorage.getItem(STORAGE_KEY));
        return Array.isArray(data) ? data : initialRequests;
    } catch (err) {
        return initialRequests; // corrupt or blocked storage
    }
}

function showToast(message, type = 'ok') {
    let t = document.getElementById('toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'toast';
        t.setAttribute('role', 'status');
        document.body.appendChild(t);
    }
    t.className = type;
    t.textContent = message;
    t.hidden = false;
    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => { t.hidden = true; }, 4000);
}

let requests = loadRequests();
let currentTab = 'active';

// Selected coordinates from the picker map
let selectedLat = null;
let selectedLng = null;
let isWithinRadius = false;

function saveRequests() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(requests)); }
    catch (err) { showToast('Could not save: browser storage is unavailable.', 'err'); }
}

function renderTable() {
    const tbody = document.getElementById('request-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    const filteredRequests = requests.filter(req => {
        return currentTab === 'active' ? req.status === 'Active' : req.status === 'Fulfilled';
    });

    if (filteredRequests.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-8 text-slate-400 text-xs">
                    <i class="fa-solid fa-box-open text-2xl mb-2 block text-slate-300"></i>
                    No ${currentTab === 'active' ? 'active requests right now' : 'fulfilled requests in history'}.
                </td>
            </tr>
        `;
    } else {
        filteredRequests.forEach((req) => {
            const isFulfilled = req.status === 'Fulfilled';
            const statusBadge = isFulfilled 
                ? `<span class="bg-teal-50 text-teal-700 px-2 py-0.5 rounded-full font-semibold text-[10px]">Fulfilled</span>`
                : `<span class="bg-rose-50 text-rose-700 px-2 py-0.5 rounded-full font-semibold text-[10px]">Active</span>`;
            
            const actionBtn = isFulfilled
                ? `<button onclick="toggleStatus(${req.id})" class="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium px-2 py-1 rounded transition border border-slate-200">Reopen</button>`
                : `<button onclick="toggleStatus(${req.id})" class="text-xs bg-emerald-50 hover:bg-emerald-600 hover:text-white text-emerald-700 font-semibold px-2 py-1 rounded transition border border-emerald-200 shadow-sm">Mark Fulfilled</button>`;

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="p-3 font-medium text-slate-800">${esc(req.org)}<br><span class="text-[10px] text-slate-400">${esc(req.location)}</span></td>
                <td class="p-3">${esc(req.item)}</td>
                <td class="p-3"><span class="px-1.5 py-0.5 bg-slate-100 rounded text-[10px]">${esc(req.urgency)}</span></td>
                <td class="p-3">${statusBadge}</td>
                <td class="p-3 text-center">${actionBtn}</td>
            `;
            tbody.appendChild(tr);
        });
    }

    updateStats();
    updateLocationSummary();
    initLiveMap();
}

function switchTab(tab) {
    currentTab = tab;
    const activeBtn = document.getElementById('tab-active');
    const historyBtn = document.getElementById('tab-history');
    const hintText = document.getElementById('table-hint');

    if (tab === 'active') {
        if (activeBtn) activeBtn.className = "px-3 py-1.5 rounded-md bg-white text-emerald-700 shadow-sm transition font-semibold";
        if (historyBtn) historyBtn.className = "px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 transition flex items-center gap-1.5 font-medium";
        if (hintText) hintText.innerText = '* Click "Mark Fulfilled" to move items into the Fulfilled History tab.';
    } else {
        if (historyBtn) historyBtn.className = "px-3 py-1.5 rounded-md bg-white text-emerald-700 shadow-sm transition font-semibold flex items-center gap-1.5";
        if (activeBtn) activeBtn.className = "px-3 py-1.5 rounded-md text-slate-600 hover:text-slate-900 transition font-medium";
        if (hintText) hintText.innerText = '* Showing completed and fulfilled requests in history.';
    }

    renderTable();
}

function toggleStatus(id) {
    const item = requests.find(r => r.id === id);
    if (item) {
        item.status = item.status === 'Active' ? 'Fulfilled' : 'Active';
        saveRequests();
        renderTable();
    }
}

function updateStats() {
    const totalRaised = requests.length;
    const fulfilledCount = requests.filter(r => r.status === 'Fulfilled').length;
    
    const statRaised = document.getElementById('stat-raised');
    const statFulfilled = document.getElementById('stat-fulfilled');
    const statItems = document.getElementById('stat-items');
    const statOrgs = document.getElementById('stat-orgs');
    const historyCount = document.getElementById('history-count');

    if (statRaised) statRaised.innerText = totalRaised;
    if (statFulfilled) statFulfilled.innerText = fulfilledCount;
    if (statItems) statItems.innerText = (totalRaised * 35);
    if (statOrgs) statOrgs.innerText = new Set(requests.map(r => r.org)).size;
    if (historyCount) historyCount.innerText = fulfilledCount;
}

function updateLocationSummary() {
    const summaryContainer = document.getElementById('location-summary-grid');
    if (!summaryContainer) return;

    const locationCounts = {};
    requests.forEach(req => {
        const loc = req.location.trim();
        locationCounts[loc] = (locationCounts[loc] || 0) + 1;
    });

    summaryContainer.innerHTML = '';
    for (const [location, count] of Object.entries(locationCounts)) {
        const card = document.createElement('div');
        card.className = "bg-slate-50 border border-slate-200 p-3 rounded-lg flex flex-col justify-between";
        card.innerHTML = `
            <span class="font-semibold text-slate-700 truncate" title="${esc(location)}">${esc(location)}</span>
            <div class="flex items-baseline justify-between mt-2">
                <span class="text-emerald-700 font-bold text-base">${count}</span>
                <span class="text-[10px] text-slate-400">Cases</span>
            </div>
        `;
        summaryContainer.appendChild(card);
    }
}

// -------------------------------------------------------------
// MAIN DASHBOARD LIVE MAP LOGIC
// -------------------------------------------------------------
let map = null;
let markersLayer = null;

function initLiveMap() {
    const mapContainer = document.getElementById('live-leaflet-map');
    if (!mapContainer || typeof L === 'undefined') return;

    if (!map) {
        map = L.map('live-leaflet-map').setView(APU_COORDS, 11);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        L.circle(APU_COORDS, {
            color: '#0284c7',
            fillColor: '#38bdf8',
            fillOpacity: 0.08,
            radius: MAX_RADIUS_METERS
        }).addTo(map);

        const apuIcon = L.divIcon({
            className: 'apu-pin',
            html: `<div style="background-color: #047857; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.4); text-align: center; color: white; font-size: 10px; line-height: 14px;">★</div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });
        L.marker(APU_COORDS, { icon: apuIcon }).addTo(map).bindPopup('<b>APU Campus Centre</b>');

        markersLayer = L.layerGroup().addTo(map);
    }

    markersLayer.clearLayers();
    const activeRequests = requests.filter(req => req.status === 'Active');

    activeRequests.forEach(req => {
        const coords = [req.lat ?? APU_COORDS[0], req.lng ?? APU_COORDS[1]];
        let pinColor = req.urgency === 'High' ? '#e11d48' : (req.urgency === 'Medium' ? '#f59e0b' : '#38bdf8');

        const customIcon = L.divIcon({
            className: 'custom-map-pin',
            html: `<div style="background-color: ${pinColor}; width: 16px; height: 16px; border-radius: 50%; border: 2.5px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.35); cursor: pointer;"></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8]
        });

        const marker = L.marker(coords, { icon: customIcon }).bindPopup(`
            <div style="font-family: sans-serif; font-size: 11px; padding: 2px;">
                <strong style="color: #0f172a; font-size: 12px;">${esc(req.org)}</strong><br>
                <span style="color: #64748b;">${esc(req.location)}</span><br>
                <div style="margin-top: 4px;"><b>Need:</b> ${esc(req.item)}</div>
                <div style="margin-top: 2px;"><b>Urgency:</b> <span style="color: ${pinColor}; font-weight: bold;">${esc(req.urgency)}</span></div>
            </div>
        `);

        markersLayer.addLayer(marker);
    });
}

// -------------------------------------------------------------
// FORM PICKER MAP LOGIC WITH ADDRESS SEARCH BAR & 10-MILE RADIUS
// -------------------------------------------------------------
let pickerMap = null;
let userMarker = null;

function initPickerMap() {
    const container = document.getElementById('picker-map');
    if (!container || pickerMap || typeof L === 'undefined') return;

    pickerMap = L.map('picker-map').setView(APU_COORDS, 12);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(pickerMap);

    // 10-Mile Visual Boundary Circle
    L.circle(APU_COORDS, {
        color: '#0284c7',
        fillColor: '#0284c7',
        fillOpacity: 0.1,
        radius: MAX_RADIUS_METERS
    }).addTo(pickerMap);

    // APU Marker
    L.marker(APU_COORDS).addTo(pickerMap).bindPopup('<b>APU Campus</b>');

    // Address search bar. Nominatim is strict, so if the full address finds nothing
    // we retry with simpler versions (no house number, no postcode, last 3 parts).
    if (L.Control.Geocoder) {
        const base = L.Control.Geocoder.nominatim({
            geocodingQueryParams: { countrycodes: 'my', limit: 5 }
        });

        const smartGeocoder = {
            geocode: function (query, cb, ctx) {
                const parts = query.split(',').map(p => p.trim()).filter(Boolean);
                const noPostcode = parts.map(p => p.replace(/\b\d{5}\b/, '').trim()).filter(Boolean);
                const variants = [
                    query,
                    parts.slice(1).join(', '),
                    noPostcode.slice(1).join(', '),
                    parts.slice(-3).join(', '),
                    parts.slice(-2).join(', ')
                ].filter((v, i, a) => v && a.indexOf(v) === i);

                let i = 0;
                const tryNext = () => {
                    if (i >= variants.length) {
                        showToast('Address not found. Try a shorter search (street + area) or click the map.', 'err');
                        return cb.call(ctx, []);
                    }
                    base.geocode(variants[i++], results => {
                        if (results && results.length) cb.call(ctx, results);
                        else setTimeout(tryNext, 1100); // stay under Nominatim's 1 request/second limit
                    });
                };
                tryNext();
            },
            suggest: function (query, cb, ctx) { cb.call(ctx, []); }
        };

        L.Control.geocoder({
            geocoder: smartGeocoder,
            defaultMarkGeocode: false,
            placeholder: 'Search address or location...'
        })
        .on('markgeocode', function(e) {
            const latlng = e.geocode.center;
            pickerMap.setView(latlng, 16);
            updatePickerPin(latlng.lat, latlng.lng);
        })
        .addTo(pickerMap);
    }

    // Map Click Listener
    pickerMap.on('click', function(e) {
        updatePickerPin(e.latlng.lat, e.latlng.lng);
    });
}

function updatePickerPin(lat, lng) {
    selectedLat = lat;
    selectedLng = lng;

    const apuLatLng = L.latLng(APU_COORDS[0], APU_COORDS[1]);
    const userLatLng = L.latLng(lat, lng);
    const distanceMeters = apuLatLng.distanceTo(userLatLng);
    const distanceMiles = (distanceMeters / 1609.34).toFixed(1);
    const distanceKm = (distanceMeters / 1000).toFixed(1);

    const statusBadge = document.getElementById('radius-status');

    if (distanceMeters <= MAX_RADIUS_METERS) {
        isWithinRadius = true;
        if (statusBadge) {
            statusBadge.className = "text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200";
            statusBadge.innerHTML = `<i class="fa-solid fa-circle-check text-emerald-600 mr-1"></i> Valid Pin (${distanceMiles} mi / ${distanceKm} km from APU)`;
        }
    } else {
        isWithinRadius = false;
        if (statusBadge) {
            statusBadge.className = "text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200";
            statusBadge.innerHTML = `<i class="fa-solid fa-circle-xmark text-rose-600 mr-1"></i> Out of 10-Mile Radius (${distanceMiles} mi / ${distanceKm} km - Too Far!)`;
        }
    }

    if (!userMarker) {
        userMarker = L.marker([lat, lng], { draggable: true }).addTo(pickerMap);
        userMarker.on('dragend', function(event) {
            const position = event.target.getLatLng();
            updatePickerPin(position.lat, position.lng);
        });
    } else {
        userMarker.setLatLng([lat, lng]);
    }
}

// -------------------------------------------------------------
// FORM SUBMISSION VALIDATION
// -------------------------------------------------------------
const form = document.getElementById('submission-form');
if (form) {
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        if (!selectedLat || !selectedLng) {
            showToast('Please search your address or click the map to pin your location first.', 'err');
            return;
        }

        if (!isWithinRadius) {
            showToast('Pinned location is outside the 10-mile radius. Please pin inside the blue circle.', 'err');
            return;
        }

        const org = document.getElementById('org-name').value.trim();
        const location = document.getElementById('org-location').value.trim();
        const item = document.getElementById('item-name').value.trim();
        const urgency = document.getElementById('item-urgency').value;

        requests.unshift({
            id: Date.now(),
            org: org,
            location: location,
            item: item,
            urgency: urgency,
            status: "Active",
            lat: selectedLat,
            lng: selectedLng
        });

        saveRequests();
        currentTab = 'active';
        switchTab('active');
        this.reset();

        // Reset Pin State
        if (userMarker) {
            pickerMap.removeLayer(userMarker);
            userMarker = null;
        }
        selectedLat = null;
        selectedLng = null;
        isWithinRadius = false;

        const statusBadge = document.getElementById('radius-status');
        if (statusBadge) {
            statusBadge.className = "text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-200";
            statusBadge.innerHTML = `<i class="fa-solid fa-triangle-exclamation mr-1"></i> Please search or tap map to set pin`;
        }

        showToast('Request submitted and pin added to the map.');
    });
}

// Render and initialize
renderTable();
initPickerMap();