// Mobile menu toggle (shared by all pages)
(function () {
    const btn = document.getElementById('menu-btn');
    const nav = document.getElementById('mobile-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', function () {
        const open = nav.classList.toggle('hidden') === false;
        btn.setAttribute('aria-expanded', String(open));
        btn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    });
    nav.addEventListener('click', function (e) {
        if (e.target.closest('a')) { nav.classList.add('hidden'); btn.setAttribute('aria-expanded', 'false'); }
    });
})();
